function nHat = computeMAPEstimateOfN(rho, M, nL, nN, lambda_c, bPlotPDF)
  
  alpha = 5;
  lambda_0 = M;
  minN = max([2*M,nN]);
  l = linspace(0,2*M,nL);
  pl = exp(-(l - lambda_0).^2./(2*alpha*lambda_0)); pl = pl./sum(pl);
  nStep = round(2*minN/nN);
  nStep = 1;
  n = 0:nStep:2*M;
  
  pNgvM = zeros(1,length(n));
  z=0;
  for kn = 1:length(n)
    
    dzn = zeros(1,length(l));
    for kl = 1:length(l);
      
      fz = (l(kl) * rho *z + lambda_c)^M; 
      gz = exp(-l(kl) - lambda_c + l(kl)*z.*(1-rho));
      
      %compile derivative at n for product of two functions
      c = 0; adder = 1;
      kdVals = [0:n(kn)];
      iKd = 1;
      bInvert = 1;
      totalDerivTerms = 0;
      for kd = kdVals
        
        %after halfway through the derivative, the number of 
        ##        %mixed derivatives decreases
        ##        if (iKd > length(kdVals)/2) && bInvert
        ##          adder = -1; bSkip = 1; bInvert = 0;
        ##        endif
        
        %except for the (f^n)(g^0) and (f^0)(g^n) derivatives,
        %the mixed (f^i)(g^j) repeat and occur x times depending on M. c is 
        %is the number of the mixed derivatives in the whole derivative
        if iKd == 1 || iKd == length(kdVals)
          c = 1;
          totalDerivTerms = totalDerivTerms + 1;
        elseif kd == (n(kn)-kd)
          c = (2^n(kn)) - 2*totalDerivTerms;
        else
          c = max([kd,n(kn)-kd])+1;
          totalDerivTerms = totalDerivTerms + c;
        endif
        
        %compute exponent of derivatives
        fexp = kd;
        gexp = n(kn)-kd;
        
        %compute derivative components
        ##        q = 0:kd; 
        ##        dq = M-q;
        ##        mq = prod(dq(dq > 0));
        dfa = (l(kl)*rho*z + lambda_c)^(M-kd);
        if fexp <= M
          mq = factorial(M)/factorial(M-fexp);
        else
          mq = 1;
        endif
        
        %compute derivatives
        dfdz = (l(kl)*rho)^fexp * dfa * mq;
        dgdz = (l(kl)*(1-rho))^gexp * gz;
        
        %if either derivative order is zero, it is the function itself
        if fexp == 0
          dfdz = fz;
        endif
        if gexp == 0
          dgdz = gz;
        endif
        
        %derivativs of f are zero for higher than M
        if kd > M
          dfdz = 0;
        endif
        
        
        %add derivative to total derivative
        c;
        dzn(kl) = dzn(kl) + c*dfdz*dgdz;
        iKd = iKd + 1;
        ##        bSkip = 0;
      endfor %endfor kd
      
      
      
    endfor %endfor kl
    ##    dzn = dzn./sum(dzn);
    %integrate out lambda
    
    pa = pl * dzn';
    pNgvM(kn) = pa;
  endfor 
  
  
  pNgvM(isinf(pNgvM)) = 0;
  pNgvM(pNgvM == 0) = max(pNgvM);
  ##f=1:length(pNgvM);
  pNgvM = pNgvM./factorial(n);
  pNgvM = pNgvM./sum(pNgvM);
  
  %normalize PNgvM to make a density
  iMax = find(pNgvM == max(pNgvM));
  iMax = find(pNgvM == max(pNgvM));
  nHat = n(iMax(1));
  
  if bPlotPDF
    figure; plot(l,pl,'color','r'); xlabel('lambda','fontweight','bold'); 
    ylabel('p(lambda)','fontweight','bold');
    figure; plot(n,pNgvM); xlabel('n','fontweight','bold');
    ylabel(['prob(N|M=',num2str(M),')'],'fontweight','bold');
    endif