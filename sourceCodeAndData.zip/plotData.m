close all;
clear

##M_Dumouchel,M_GF, Nhat,log(PLambdaHat),log(PNHat)
pd07Data = csvread('pd0.7_clutter8.csv');
pd08Data = csvread('pd0.8_clutter8.csv');
pd09Data = csvread('pd0.9_clutter8.csv');
pd095Data = csvread('pd0.95_clutter8.csv');

figure; plot(pd07Data(:,end),'k','linewidth',2); hold on;
plot(pd08Data(:,end),'k','linestyle','--','linewidth',1);
plot(pd09Data(:,end),'k','linestyle','-.','linewidth',1);
plot(pd095Data(:,end),'k','linestyle',':','linewidth',1);
grid on


legend('P_d = 0.7','P_d = 0.8','P_d = 0.9','P_d = 0.95');

figure; plot(pd09Data(:,end),'k','linewidth',1); hold on;
plot(pd09Data(:,end-1),'k','linestyle','--','linewidth',1);
legend('BacSD','EB');
grid on
ylabel('ADR Rank \alpha ()','fontweight','bold','fontsize',16)
xlabel('ADR ID','fontweight','bold','fontsize',16)

[pd09Data(:,1),pd09Data(:,2), pd08Data(:,2), pd07Data(:,2), pd07Data(:,3)]
