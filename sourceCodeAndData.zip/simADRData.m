function [simCounts, simMedIDStr, simAdr]= simADRData(lambdaC,distribution)

  load adrAndIdSample

  maxVal = 5000;
  nVals = 5000;
  largeValPer = 0.1;
  nLarge = round(nVals*largeValPer);
  simMedIDStr = cell(nVals,1);
  simAdr = cell(nVals,1);
  nSampleADRData = length(adr);
  iSample = round(rand(1,nVals)*nSampleADRData);
  iSample(iSample > length(medIDStr)) = nSampleADRData;
  iSample(iSample == 0) = 1;
  simMedIDStr = medIDStr(iSample);
  simAdr = adr(iSample);



  % poisson distribution
  if (distribution == 0)
    probs = rand(1,nVals);
    simCounts = poissinv(probs,lambdaC);
  else %uniform distribution
    simCounts = rand(1,nVals)*lambdaC;
  endif

  simCountsLarge = rand(1,nLarge)*maxVal;
  simCounts(1:nLarge) = simCounts(1:nLarge) + simCountsLarge;
  simCounts = round(simCounts);

endfunction
