close all
clear
clc

pkg load statistics


minCount = 20;
maxCount = 75;
simLambdaC = 50;
##  pd = 0.1; %probability of detection
bProcessRawData = 0;
bSimData = 0;
bEstimateDuMouchelParameters = 0;
distribution  = 1; %0 - Poisson, 1 - uniform

if bProcessRawData
  if ~bSimData
    fid = fopen('medDataFreqOnly.csv','r');
    medsAndFreq =textscan(fid,'%s,%f,%f,%s',"Delimiter",",");
    fclose(fid);
    nRows = length(medsAndFreq{1});
    ##  medID = zeros(nRows,1);
    medIDStr = medsAndFreq{1};
    medIDStr(end) = [];
    fLow = zeros(nRows,1);
    fHigh = zeros(nRows,1);
    adr = medsAndFreq{4};
    for k = 1:nRows-1
      ##    medIDS = medsAndFreq{1}(k);
      ##    medIDS = medIDS{1};
      ##    medID(k) = round(str2num(medIDS(4:end)));
      fLow(k) = medsAndFreq{2}(k);
      fHigh(k) = medsAndFreq{3}(k);
    end
    ##  medID = round(medID - medID(1));
    ##  medID(end) = [];
    fLow(end) = [];
    fHigh(end) = [];
    freq = mean([fLow,fHigh],2);
    ##figure; plot(medID)
    ##  figure; plot(medID,freq);
    ##  xlabel('drug ID','fontweight','bold')
    ##  ylabel('ADR frequency','fontweight','bold')

    %normalize frequencies to integrate to one and convert to counts
    freq = freq./sum(freq);
    counts = round(freq./min(freq(freq > 0)));

  else %use simulated datasample
  disp('using simulated data');
  [simCounts, simMedIDStr, simAdr]= simADRData(simLambdaC,distribution);
    counts = simCounts;
    medIDStr = simMedIDStr;
    adr = simAdr;
  endif

  disp('conditioning unique entries...');
  [medIDCounts, uniqueMedIDStrs, uniqueADRStrs, medIDvsADR] = ...
  conditionMedraData(counts, medIDStr, adr);

  counts = reshape(medIDvsADR',prod(size(medIDvsADR)),1);
##  medID = uniqueMedIDs;
  medIDStr = uniqueMedIDStrs;
  adr = uniqueADRStrs;

  [xx,yy] = meshgrid(1:length(uniqueADRStrs),1:length(uniqueMedIDStrs));
  figure; surf(xx,yy,medIDvsADR)

  %remove zero counts and too few counts
  ##    iZ = find(counts == 0);
  ##    counts(iZ) = [];
  ##    medID(iZ) = [];
  ##    adr(iZ) = [];
  ##    medIDStr(iZ) = [];
  ##    iMin = find(counts < minCount);
  ##    counts(iMin) = [];
  ##    medID(iMin) = [];
  ##    adr(iMin) = [];
  ##    medIDStr(iMin) = [];

  %renormalize counts to smallest possible integer
  ##    nCounts = counts./max(counts);
  ##    nCountLvl = ceil(1/min(nCounts));
  ##    counts = counts./max(counts);
  ##    counts = ceil(counts.*nCountLvl);

  ##    uniqueADRs = cell(1,1);
  ##    uniqueADRs{1} = adr{1};
  ##   for kADR = 1:length(adr);
  ##      strFound = 0;
  ##      for kUADR = 1:length(uniqueADRs)
  ##
  ##        %if new ADR found, add it in
  ##        if strcmp(adr{kADR},uniqueADRs{kUADR})
  ##          strFound = 1;
  ##        endif
  ##
  ##      endfor
  ##
  ##      if ~strFound
  ##        uniqueADRs{end+1} = adr{kADR};
  ##      endif
  ##    endfor
  ##    uniqueADRs(end) = [];
  ##
  ##    uniqueMedIDs = unique(medID);
  ##
  ##    adrVsmed = zeros(length(uniqueMedIDs),length(uniqueADRs));
  ##    %populate into matrix
  ##    for kMed = 1:length(medID)
  ##      mID = medID(kMed);
  ##      adrStr = adr{kMed};
  ##      count = counts(kMed);
  ##      row = find(uniqueMedIDs == mID);
  ##      col = 1;
  ##      for kADR = 1:length(uniqueADRs)
  ##        if strcmp(adrStr,uniqueADRs{kADR})
  ##          col = kADR;
  ##          break;
  ##        endif
  ##      endfor
  ##      adrVsmed(row,col) = adrVsmed(row,col) + count;
  ##    endfor
  ##    [xx,yy] = meshgrid(1:length(uniqueADRs),1:length(uniqueMedIDs));
  ##    figure; surf(xx,yy,adrVsmed)

  ##  fit clutter model. assume poison distributed total noise points L corresponding to
  ##  lambda. the noise points are assumed equally distributed across the N bins.
  ##
  ##  high counts imply causality. remove points and estimate lambda until the counts
  ##  remaining maximize a noise assumption.
  ##  sort counts
    tempCounts = counts(counts > 0);
  sortedCounts = sort(tempCounts,'descend');
  lastLikelihood = 0;
  numBins = length(tempCounts);
  L = 2*numBins; %initial L
  lVals = round(10*L*0.8.^[20:5:40]);
  ##  lVals = 22;
  alphaVals = 0.9:-0.1:0.1;
  likelihood = zeros(length(lVals),length(alphaVals));
  for kL = 1:length(lVals)
    for kAlpha = 1:length(alphaVals)


      nPerBin = lVals(kL)/numBins;
      [numInBin, binCenters] = hist(tempCounts,1e3);
      pBin = numInBin./sum(numInBin);
      pAlpha = 0;
      for kBin = 1:length(pBin)
        pAlpha = pAlpha + pBin(kBin);
        if pAlpha >= alphaVals(kAlpha);
          signalThreshold = binCenters(kBin);
          break;
        endif
      endfor

      subCount = tempCounts(tempCounts < signalThreshold);
      varmodel = (1/12)*(nPerBin)^2;
      meanmodel = nPerBin/2;
      counthat = mean(subCount);
      varhat = var(subCount);
      beta = 500;
      ##        lambda^k * exp(-lambda)/k!
      val = (lVals(kL).^subCount).*exp(-lVals(kL)) ./ factorial(subCount);
      likelihood(kL,kAlpha) = sum(val(~isnan(val) & ~isinf(val)));
      ##        likelihood(kL,kAlpha) = exp(-((meanmodel - counthat)^2) / beta^2) + exp(-((varmodel - varhat)^2)/beta^2);
      ##dl = likelihood - lastLikelihood;
      ##lastLikelihood = likelihood;


      %remove some counts and decrement lambda
      ##alpha = alpha - 0.01;
      ##L = L - 1;
      ##sortedCounts = sort(sortedCounts,'descend');
      ##if dl < 0; break; end;
    endfor
  endfor

  figure; imagesc(likelihood)
  [ilMax,ialphaMax] = find(likelihood == max(max(likelihood)));
  lMax = lVals(ilMax);
  lMax = lMax(1);
  alphaMax = alphaVals(ialphaMax)

  ##    u = 1;
  ##    pc = 1/(lMax/numBins); %IID uniform clutter per bin
  ##    py = sum(adrVsmed)./sum(sum(adrVsmed));


  lambda_c = lMax; %mean of Poisson clutter (false ADR reports)
  save testData counts lambda_c adr medIDStr medIDvsADR

else
  load testData
endif

maxCount = 75;

scaleFactor = maxCount/max(counts);
subCounts = round(counts*scaleFactor);
lambda_c = lambda_c*scaleFactor;


##  subCounts = counts(counts < maxCount);
##  subADRs = adr(counts < maxCount);
subADRs = adr;
subMedIDStr = medIDStr;
##  subMedIDStr = medIDStr(counts < maxCount);
nL = 20;
nN = 50;
pd = 0.9;
bPlotPDF = 0;
##  iCounts = round(rand(1,20)*length(subCounts));
iNZ = find(subCounts(1:length(adr)) > 0);
iCounts = iNZ(1:15); #focuses on L-Caritine
iCounts(1) = 625;
##  iCounts = 1:20;
nHat = zeros(1,length(iCounts));


for iCount = 1:length(iCounts)
  iCount
  M = subCounts(iCounts(iCount)); %number of observations (ADR reports)
  nHat(iCount) = computeMAPEstimateOfN(pd, M, nL, nN, lambda_c, bPlotPDF);

endfor
##
##    figure; plot(subCounts(iCounts),nHat,'linestyle','none','marker','.',...
##    'markersize',20);
##    xlabel('# of ADRs','fontweight','bold')
##    ylabel('nHat','fontweight','bold')
##
pNhat = lambda_c.^nHat.*exp(-lambda_c)./factorial(nHat);
##    pNhat = 1-pNhat;
pNhat = log(pNhat);
pNhat = pNhat*-1;
pNhat(nHat == 0) = min(pNhat);
##    figure; plot(nHat,pNhat,'linestyle','none','marker','.',...
##    'markersize',20);
##    xlabel('nHat','fontweight','bold')
##    ylabel('Prob(Poisson(nHat|lambdac))','fontweight','bold')

[sortedPNHat, iNHatSorted] = sort(pNhat,'descend');

##    figure; plot(sortedPNHat);



if bEstimateDuMouchelParameters
  %dumouchel ML search for parameters alpha1, beta1, alpha2, beta2, and p
  nSearchPoints = 3;
  alpha1_0 = 0.2;
  beta1_0 = 0.1;
  alpha2_0 = 2;
  beta2_0 = 4;
  p0 = 0.3

  ##  alpha1s = (rand(1,nSearchPoints) - 0.5)*2*alpha1_0/2 + alpha1_0;
  ##  beta1s = (rand(1,nSearchPoints) - 0.5)*2*beta1_0/2 + beta1_0;
  ##  alpha2s = (rand(1,nSearchPoints) - 0.5)*2*alpha2_0/2 + alpha2_0;
  ##  beta2s = (rand(1,nSearchPoints) - 0.5)*2*beta2_0/2 + beta2_0;
  ##  ps = (rand(1,nSearchPoints) - 0.5)*2*p0/2 + p0;

  alpha1s = linspace(alpha1_0-alpha1_0/2,alpha1_0+alpha1_0/2,nSearchPoints);
  beta1s = linspace(beta1_0-beta1_0/2,beta1_0+beta1_0/2,nSearchPoints);
  alpha2s = linspace(alpha2_0-alpha2_0/2,alpha2_0+alpha2_0/2,nSearchPoints);
  beta2s = linspace(beta2_0-beta2_0/2,beta2_0+beta2_0/2,nSearchPoints);
  ps = linspace(p0-p0/2,p0+p0/2,nSearchPoints);

  maxL = 0;
  alpha1hat = 0;
  alpha2hat = 0;
  beta1hat = 0;
  beta2hat = 0;
  phat = 0;
  for alpha1 = alpha1s
    for alpha2 = alpha2s
      for beta1 = beta1s;
        for beta2 = beta2s;
          for p = ps;
            l = 1;
            for m = counts';
              %evaluate likelihood alpha1, beta1, alpha2, beta2, p assuming density is
              ##    combination of two gammas:  l = g1 + pg2;
              ##    g(x) = beta^(alpha) * x^(alpha-1) * exp(-beta*alpha) / (alpha-1)!

              l = p*(beta1^(alpha1) * m^(alpha1-1) * exp(-beta1*alpha1) / factorial(ceil(alpha1-1))) + ...
              (1-p) *(beta2^(alpha2) * m^(alpha2-1) * exp(-beta2*alpha2) / factorial(ceil(alpha2-1))) ;

              l = l*l;

            endfor

            if l > maxL
              maxL = l;
              alpha1hat = alpha1;
              alpha2hat = alpha2;
              beta1hat = beta1;
              beta2hat = beta2;
              phat = p;
            endif


          endfor
        endfor
      endfor
    endfor
  endfor
else

  load dumouchelParameters;
  alpha1hat = 5;, beta1hat = 1; alpha2hat = 10; beta2hat = 14; phat = 1/3;

endif


ev = lambda_c;

lambdaHats = zeros(size(subCounts(iCounts)));

##alpha1 = 6;, beta1 = 0.5; alpha2 = 2.5; beta2 = 0.5; p = 1/3;
lambda = 1:1:30;

for iVal = 1:length(iCounts)

  n = 1:1:100;

  c = subCounts(iCounts(iVal));
  alpha1n = alpha1hat + c;
  beta1n = beta1hat + ev;
  alpha2n = alpha2hat + c;
  beta2n = beta2hat + ev;

  f1 = (1 + beta1hat/ev)^-c * (1 + ev/beta1hat)^-alpha1hat * factorial(ceil(alpha1hat + c - 1)) ...
  / (factorial(ceil(alpha1hat-1))*factorial(ceil(c)));
  f2 = (1 + beta2hat/ev)^-c * (1 + ev/beta2hat)^-alpha2hat * factorial(ceil(alpha2hat + c - 1)) ...
  / (factorial(ceil(alpha2hat-1))*factorial(ceil(c)));

  qn = phat*f1/(phat*f1 + (1-phat)*f2);


  g1n = beta1n^(alpha1n).*lambda.^(alpha1n-1).*exp(-beta1n.*lambda)/factorial(ceil(alpha1n-1));
  g2n = beta2n^(alpha2n).*lambda.^(alpha2n-1).*exp(-beta2n.*lambda)/factorial(ceil(alpha2n-1));
  gn = qn*g1n + (1-qn)*g2n;

  ##figure; plot(lambda, g1n,'b'); hold on;
  ##plot(lambda, g2n, 'r'); plot(lambda, gn,'k');

  lambdaHats(iVal) = qn*(alpha1n)/beta1n + (1-qn)*alpha2n/beta2n;

endfor


[sortedLambdaHat, iSortedLambdaHat] = sort(log(lambdaHats),'descend');
figure; plot(sortedLambdaHat,'k'); hold on;
pNHatNorm = sortedPNHat - (sortedPNHat(1) - sortedLambdaHat(1));
plot(pNHatNorm,'color','k','linestyle','--');
legend('GPMS','BacSD');
xlabel('ADR ID','fontweight','bold','fontsize',16);
ylabel('ADR Rank \alpha','fontweight','bold','fontsize',16);

[iSortedLambdaHat, iNHatSorted' subCounts(iCounts(iSortedLambdaHat)) ...
subCounts(iCounts(iNHatSorted)) nHat(iNHatSorted)']
[sortedLambdaHat sortedPNHat' ]

fid = fopen(['pd',num2str(pd),'_clutter',num2str(round(lambda_c)),'.csv'],'w');
fprintf(fid,"M_Dumouchel,M_GF, Nhat,log(PLambdaHat),log(PNHat)\n");

for iOut = 1:length(iSortedLambdaHat)
  strOut = sprintf("%d,%d,%d,%2.2f,%2.2f\n", subCounts(iCounts(iSortedLambdaHat(iOut))), ...
  subCounts(iCounts(iNHatSorted(iOut))), nHat(iNHatSorted(iOut)), sortedLambdaHat(iOut), pNHatNorm(iOut));
  fprintf(fid, "%s",strOut);
endfor

fclose(fid);
subADRsSorted = subADRs(iNHatSorted);
subADRsSortedDM = subADRs(iSortedLambdaHat);
subMedIDStrSorted = subMedIDStr(iNHatSorted);

for k = 1:length(iNHatSorted)
  printf('%s, %s\n',subADRsSortedDM{k},subADRsSorted{k})
endfor


