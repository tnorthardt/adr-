function [uniqueCounts, uniqueMedIDStrs, uniqueADRStrs, medIDvsADR] = ...
  conditionMedraData(counts, medIDStr, adr)

  [uniqueMedIDStrs iMedIDs] = unique(medIDStr);
  uniqueADRStrs = unique(adr);
  uniqueCounts = zeros(size(uniqueMedIDStrs));

  for iMedID = 1:length(uniqueMedIDStrs)
    for kCount = 1:length(counts)
      if strcmp(uniqueMedIDStrs(iMedID),medIDStr(kCount))
        uniqueCounts(iMedID) = uniqueCounts(iMedID) + counts(kCount);
      endif
    endfor
  endfor

  medIDvsADR = zeros(length(iMedIDs),length(uniqueADRStrs));
  for kCount = 1:length(counts)

    iMedID = 1;
    for kMedID = 1:length(iMedIDs)
      if strcmp(uniqueMedIDStrs(kMedID),medIDStr(kCount))
        iMedID = kMedID;
      endif
    endfor

    iADR = 1;
    for kADR = 1:length(uniqueADRStrs)
      if strcmp(uniqueADRStrs(kADR),adr(kCount))
        iADR = kADR;
      endif
    endfor
    medIDvsADR(iMedID,iADR) =  medIDvsADR(iMedID,iADR) + counts(kCount);

  endfor

